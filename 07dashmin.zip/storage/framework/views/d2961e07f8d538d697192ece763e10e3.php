<?php $__env->startSection('contenido'); ?>
<!-- Sale & Revenue Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12">
            <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                <h1>Panel de ventas</h1>
            </div>
        </div>
    </div>
</div>
<!-- Sale & Revenue End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vistadashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\web3\05dashmin\resources\views/ventas/panel.blade.php ENDPATH**/ ?>